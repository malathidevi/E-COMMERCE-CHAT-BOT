Hi Folks this is Naresh 

# Customer-chatbot


![home page](<![alt text](<images/Screenshot 2024-03-22 102028.png>)>)
![chat page](<![alt text](<images/Screenshot 2024-03-22 101940.png>)>)

## Installation Guide

### Requirements
1.python
2.flask

## model
-we are using Rasa NLU
-Rasa is a tool which is used to build custom AI chatbots using python and NLU
-NLU stands for Natural language understanding it deals with human language
